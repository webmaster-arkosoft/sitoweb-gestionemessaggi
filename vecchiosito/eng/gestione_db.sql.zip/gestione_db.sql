-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generato il: 22 mar, 2011 at 07:25 PM
-- Versione MySQL: 5.0.92
-- Versione PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gestione_db`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `commenti`
--

CREATE TABLE IF NOT EXISTS `commenti` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `nome` text NOT NULL,
  `email` text NOT NULL,
  `sito` text NOT NULL,
  `avatar` text NOT NULL,
  `testo` text NOT NULL,
  `data` datetime NOT NULL,
  `approvato` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dump dei dati per la tabella `commenti`
--

INSERT INTO `commenti` (`id`, `nome`, `email`, `sito`, `avatar`, `testo`, `data`, `approvato`) VALUES
(1, 'Gianluca', '', '', 'avatar/avatar2.jpg', 'Ho scaricato il vostro software, ma la lista dei telefonini mi sembra un po'' carente, comunque ho provato ad utilizzare i crediti e devo dire che la velocità di invio degli sms mi ha soddisfatto', '2010-07-09 11:34:17', 1),
(2, 'Max 69', '', '', 'avatar/avatar.jpg', 'Ho un negozio di animali, e ho suddiviso i miei clienti in base al tipo di animale del cliente, questo metodo mi permette di mirare le offerte. Ho approfittato per comprare un nuovo cellulare, di quelli compatibili col programma e grazie all''offerta col mio operatore mobile riesco anche a risparmiare tempo e denaro. Molto innovativo.', '2010-07-12 10:36:26', 1),
(3, 'Sara', '', '', 'avatar/avatar4.jpg', 'Io ho un negozio di scarpe, e come Max 69 ho catalogato i miei clienti in base alle loro marche preferite, così ogni volta che arriva un nuovo prodotto in negozio, posso aggiornarli subito oppure proporli delle offerte. Questo programma è davvero rivoluzionario!', '2010-07-16 09:17:03', 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `download`
--

CREATE TABLE IF NOT EXISTS `download` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `ragione` text NOT NULL,
  `tipo` text NOT NULL,
  `cognome` text NOT NULL,
  `nome` text NOT NULL,
  `piva` text NOT NULL,
  `codfiscale` text NOT NULL,
  `telefono` text NOT NULL,
  `email` text NOT NULL,
  `cap` int(10) NOT NULL,
  `citta` text NOT NULL,
  `prov` text NOT NULL,
  `indirizzo` text NOT NULL,
  `cellulare` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dump dei dati per la tabella `download`
--

INSERT INTO `download` (`id`, `ragione`, `tipo`, `cognome`, `nome`, `piva`, `codfiscale`, `telefono`, `email`, `cap`, `citta`, `prov`, `indirizzo`, `cellulare`) VALUES
(40, '', 'Ditta', 'kingk85', 'kingk', '', 'crmguo85m18g141s', '', 'kingk85@gmail.com', 10, 'Roma', 'RM', 'pza della mad', ''),
(39, 'Arkosoft', 'S.A.S.', 'Basile', 'stefano', '', '', '', 'info@arkosoft.it', 72026, 'san pancrazio salentino', 'BR', 'via pigna', ''),
(41, '', '0', 'Patruno', 'Angelo', '', '', '', 'patruno44@libero.it', 72100, 'Brindisi', 'BR', 'via Stazione, 15', '');

-- --------------------------------------------------------

--
-- Struttura della tabella `statodownload`
--

CREATE TABLE IF NOT EXISTS `statodownload` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `idutente` int(10) NOT NULL,
  `codice` text NOT NULL,
  `statodownload` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dump dei dati per la tabella `statodownload`
--

INSERT INTO `statodownload` (`id`, `idutente`, `codice`, `statodownload`) VALUES
(35, 40, 'a2lua2lua2luNA==', 1),
(34, 39, 'c3RlQmFzaW5mMjM=', 1);
